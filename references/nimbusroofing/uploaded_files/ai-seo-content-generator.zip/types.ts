
export interface AdSnippet {
  header: string;
  values: string[];
}

export interface GeneratedContent {
  broadKeywords: string[];
  longTailKeywords: string[];
  serviceSpecificKeywords: string[];
  googleAdsSnippets: AdSnippet[];
}
