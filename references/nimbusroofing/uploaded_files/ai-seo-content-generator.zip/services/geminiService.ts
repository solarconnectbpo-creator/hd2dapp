
import { GoogleGenAI, Type } from "@google/genai";
import type { GeneratedContent } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const contentSchema = {
    type: Type.OBJECT,
    properties: {
        broadKeywords: {
            type: Type.ARRAY,
            description: 'High-volume, competitive keywords for general visibility related to roofing in McKinney, TX and DFW area.',
            items: { type: Type.STRING }
        },
        longTailKeywords: {
            type: Type.ARRAY,
            description: 'Detailed, multi-word phrases with high conversion potential, focusing on specific user needs like "hail damage roof repair cost".',
            items: { type: Type.STRING }
        },
        serviceSpecificKeywords: {
            type: Type.ARRAY,
            description: 'Keywords focused on specific services (e.g., roof repair, replacement, inspection) and materials (e.g., asphalt shingle, metal roofing).',
            items: { type: Type.STRING }
        },
        googleAdsSnippets: {
            type: Type.ARRAY,
            description: 'Three distinct structured snippet assets for Google Ads: one for "Services", one for "Types" of roofing, and one for "Amenities" offered. Values must be 25 characters or less.',
            items: {
                type: Type.OBJECT,
                properties: {
                    header: { type: Type.STRING, description: 'The header for the snippet (Services, Types, or Amenities).' },
                    values: { type: Type.ARRAY, description: "List of values for the snippet. Each value must be 25 characters or less.", items: { type: Type.STRING } }
                },
                required: ["header", "values"],
            }
        }
    },
    required: ["broadKeywords", "longTailKeywords", "serviceSpecificKeywords", "googleAdsSnippets"],
};


export async function refinePrompt(rawPrompt: string): Promise<string> {
  const systemInstruction = `You are an expert prompt engineer. Your task is to rephrase the user's input into a clear, concise, and effective prompt for a generative AI. The goal is to generate SEO keywords and Google Ads content for a roofing company named "Nimbus Roofing" targeting McKinney, TX and the DFW metroplex. Extract the key entities, goals, and constraints from the user's text and structure them into a direct command for the AI. The output should be a single, optimized prompt.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Here is the raw input from the user:\n\n---\n${rawPrompt}\n---`,
    config: {
        systemInstruction,
        temperature: 0.2,
    }
  });

  return response.text;
}

export async function generateSeoContent(prompt: string): Promise<GeneratedContent> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
        responseMimeType: "application/json",
        responseSchema: contentSchema,
        temperature: 0.7,
    }
  });

  const jsonText = response.text.trim();
  try {
    const parsedJson = JSON.parse(jsonText);
    return parsedJson as GeneratedContent;
  } catch (error) {
    console.error("Failed to parse Gemini JSON response:", jsonText);
    throw new Error("The AI returned an invalid data format.");
  }
}
