
import React from 'react';
import type { GeneratedContent } from '../types';
import GeneratedSection from './GeneratedSection';
import Loader from './Loader';

interface ContentDisplayProps {
  refinedPrompt: string;
  generatedContent: GeneratedContent | null;
  isLoading: boolean;
}

const ContentDisplay: React.FC<ContentDisplayProps> = ({ refinedPrompt, generatedContent, isLoading }) => {
  if (!refinedPrompt && !isLoading) {
    return null;
  }

  return (
    <div className="mt-10 space-y-8">
      {refinedPrompt && (
        <GeneratedSection title="Refined AI Prompt" isPrompt>
            <p className="text-text-secondary whitespace-pre-wrap font-mono text-sm">{refinedPrompt}</p>
        </GeneratedSection>
      )}

      {isLoading && !generatedContent && (
        <div className="mt-8 flex flex-col items-center justify-center">
            <Loader />
            <p className="mt-4 text-text-secondary text-lg">Generating SEO content...</p>
        </div>
      )}

      {generatedContent && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <GeneratedSection title="Broad Keywords">
            <ul className="space-y-2">
              {generatedContent.broadKeywords.map((kw, i) => <li key={i} className="text-text-secondary">{kw}</li>)}
            </ul>
          </GeneratedSection>
          <GeneratedSection title="Long-Tail Keywords">
            <ul className="space-y-2">
              {generatedContent.longTailKeywords.map((kw, i) => <li key={i} className="text-text-secondary">{kw}</li>)}
            </ul>
          </GeneratedSection>
          <GeneratedSection title="Service-Specific Keywords">
            <ul className="space-y-2">
              {generatedContent.serviceSpecificKeywords.map((kw, i) => <li key={i} className="text-text-secondary">{kw}</li>)}
            </ul>
          </GeneratedSection>

          {generatedContent.googleAdsSnippets.map((snippet, index) => (
            <GeneratedSection key={index} title={`Google Ads: ${snippet.header}`}>
               <ul className="space-y-2">
                 {snippet.values.map((val, i) => (
                    <li key={i} className="text-text-secondary bg-base-100/50 px-2 py-1 rounded-md">{val}</li>
                 ))}
               </ul>
            </GeneratedSection>
          ))}
        </div>
      )}
    </div>
  );
};

export default ContentDisplay;
