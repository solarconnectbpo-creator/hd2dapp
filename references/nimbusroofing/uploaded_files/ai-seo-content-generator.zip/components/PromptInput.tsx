
import React from 'react';

interface PromptInputProps {
  rawPrompt: string;
  setRawPrompt: (prompt: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const PromptInput: React.FC<PromptInputProps> = ({ rawPrompt, setRawPrompt, onGenerate, isLoading }) => {
  return (
    <div className="bg-base-200 p-6 rounded-xl shadow-lg border border-base-300">
      <label htmlFor="prompt-input" className="block text-lg font-semibold mb-3 text-text-primary">
        Your Marketing & SEO Brief
      </label>
      <textarea
        id="prompt-input"
        value={rawPrompt}
        onChange={(e) => setRawPrompt(e.target.value)}
        placeholder="Enter your detailed brief here..."
        className="w-full h-64 p-4 bg-base-100 border border-base-300 rounded-md text-text-secondary focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition-shadow duration-300 resize-y"
        disabled={isLoading}
      />
      <div className="mt-6 flex justify-end">
        <button
          onClick={onGenerate}
          disabled={isLoading}
          className="px-8 py-3 bg-brand-primary hover:bg-brand-secondary text-white font-bold rounded-lg shadow-md transition-all duration-300 transform hover:scale-105 disabled:bg-base-300 disabled:cursor-not-allowed disabled:scale-100 flex items-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </>
          ) : (
            'Refine & Generate Content'
          )}
        </button>
      </div>
    </div>
  );
};

export default PromptInput;
