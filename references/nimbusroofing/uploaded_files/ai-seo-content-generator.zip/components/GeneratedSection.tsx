
import React, { useState, useCallback, useRef, useEffect } from 'react';
import ClipboardIcon from './icons/ClipboardIcon';
import CheckIcon from './icons/CheckIcon';

interface GeneratedSectionProps {
  title: string;
  children: React.ReactNode;
  isPrompt?: boolean;
}

const GeneratedSection: React.FC<GeneratedSectionProps> = ({ title, children, isPrompt = false }) => {
  const [isCopied, setIsCopied] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleCopy = useCallback(() => {
    if (contentRef.current) {
      navigator.clipboard.writeText(contentRef.current.innerText).then(() => {
        setIsCopied(true);
      });
    }
  }, []);

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  const cardClasses = isPrompt 
    ? "bg-gradient-to-br from-base-200 to-base-300/50" 
    : "bg-base-200";

  return (
    <div className={`p-6 rounded-xl shadow-lg border border-base-300 flex flex-col ${cardClasses} transition-all duration-300 hover:border-brand-accent/50`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-brand-accent">{title}</h3>
        <button
          onClick={handleCopy}
          className="p-2 rounded-full text-text-secondary hover:bg-base-300 hover:text-text-primary transition-colors duration-200"
          aria-label="Copy to clipboard"
        >
          {isCopied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
        </button>
      </div>
      <div ref={contentRef} className="flex-grow">
        {children}
      </div>
    </div>
  );
};

export default GeneratedSection;
