
import React, { useState, useCallback } from 'react';
import type { GeneratedContent } from './types';
import { refinePrompt, generateSeoContent } from './services/geminiService';
import PromptInput from './components/PromptInput';
import ContentDisplay from './components/ContentDisplay';
import Loader from './components/Loader';

const INITIAL_PROMPT = `Rephrase into a prompt in which the ai will take instructions on producing vector, png, keywords and longtail keyworded NimbusRoofing.com/website content for and modern build ai first websites with headless RESTFul, Api,restful api's.. Godaddy dns, google gemini cloud dev/dustindmooreai and DallasAIRoofer@nimbusroofing.com. and genaifirst@nimbusiq.ai | 2146126696: this document into the Grok: Analyze the attached CSV files ("companycam_project_list-1969-04-20-2025-08-30.csv" and "project_list-1969-04-20-202508-30.csv") to extract location patterns, project names, and labels focused on McKinney, TX and surrounding areas. Use this data to generate a comprehensive list of optimized keywords and long-tail keywords for roofing services, emphasizing local SEO for the DFW metroplex. Prioritize high-intent, service-specific, and geographic modifiers. Integrate these keywords into recommendations for Google Ads structured snippet assets at the account, campaign, and ad group levels, ensuring they serve together for high predicted performance. Create sample snippets with headers like "Services", "Types and "Amenities", adhering to the 25-character limit per value.
Prompt 12: SEO Keyword Generation & Optimization
Grok: Based on the project data from the CSV files (e.g., addresses in McKinney, Prosper, Frisco, Allen, and labels like "QuickBooks Online Customer, Invoice Attached "), generate a list of broad, long-tail, and intent-based keywords tailored for nimbusroofing.com. Focus on roofing repairs, replacements, storm damage, and insurance claims in McKinney, TX. Use tables to organize keywords by category for clarity. Recommend integration into the website's content (e.g., landing pages, blog posts) and Google Ads structured snippets . Ensure keywords are substantiated by real project trends, such as frequent McKinney addresses and labels indicating completed jobs.`;

const App: React.FC = () => {
  const [rawPrompt, setRawPrompt] = useState<string>(INITIAL_PROMPT);
  const [refinedPrompt, setRefinedPrompt] = useState<string>('');
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!rawPrompt.trim()) {
      setError('Please enter a prompt.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setRefinedPrompt('');
    setGeneratedContent(null);

    try {
      const refined = await refinePrompt(rawPrompt);
      setRefinedPrompt(refined);

      const content = await generateSeoContent(refined);
      setGeneratedContent(content);

    } catch (e) {
      console.error(e);
      setError('An error occurred while generating content. Please check the console for details.');
    } finally {
      setIsLoading(false);
    }
  }, [rawPrompt]);

  return (
    <div className="min-h-screen text-text-primary p-4 sm:p-6 lg:p-8 font-sans">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-green-300 mb-2">
            AI SEO Content Generator
          </h1>
          <p className="text-lg text-text-secondary">
            Refine your marketing brief and generate powerful SEO content for your roofing business.
          </p>
        </header>

        <main>
          <PromptInput
            rawPrompt={rawPrompt}
            setRawPrompt={setRawPrompt}
            onGenerate={handleGenerate}
            isLoading={isLoading}
          />

          {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-500 text-red-300 rounded-lg text-center">{error}</div>}
          
          {isLoading && !refinedPrompt && (
              <div className="mt-8 flex flex-col items-center justify-center">
                  <Loader />
                  <p className="mt-4 text-text-secondary text-lg">Refining your prompt...</p>
              </div>
          )}

          <ContentDisplay 
            refinedPrompt={refinedPrompt}
            generatedContent={generatedContent}
            isLoading={isLoading}
          />
        </main>

        <footer className="text-center mt-12 text-text-secondary/50 text-sm">
            <p>Powered by Google Gemini. Built for Nimbus Roofing.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
