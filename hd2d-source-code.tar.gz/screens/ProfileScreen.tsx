import React from "react";
import { View, StyleSheet, Pressable, ScrollView, Alert, Platform } from "react-native";
import { Feather } from "@expo/vector-icons";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { Avatar } from "@/components/Avatar";
import { Badge } from "@/components/Badge";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing, BorderRadius, AppColors } from "@/constants/theme";
import type { ProfileStackParamList } from "@/navigation/ProfileStackNavigator";
import * as Haptics from "expo-haptics";

type ProfileScreenProps = {
  navigation: NativeStackNavigationProp<ProfileStackParamList, "Profile">;
};

const STATS = [
  { label: "Deals Closed", value: "47", icon: "check-circle" },
  { label: "Revenue", value: "$285K", icon: "dollar-sign" },
  { label: "Certifications", value: "3", icon: "award" },
];

const MENU_ITEMS = [
  { key: "Courses", icon: "book-open", label: "Courses & Certifications" },
  { key: "Jobs", icon: "briefcase", label: "Job Postings" },
];

const RECENT_ACTIVITY = [
  { type: "deal", text: "Closed deal with Miller Residence", time: "2 hours ago" },
  { type: "cert", text: "Earned Solar Pro Certification", time: "1 day ago" },
  { type: "course", text: "Completed Advanced Closing course", time: "3 days ago" },
];

export default function ProfileScreen({ navigation }: ProfileScreenProps) {
  const { theme } = useTheme();
  const { user, logout } = useAuth();
  const { paddingTop, paddingBottom } = useScreenInsets();

  const handleMenuPress = (key: string) => {
    if (key === "Courses" || key === "Jobs") {
      navigation.navigate(key as any);
    }
  };

  const handleLogout = async () => {
    if (Platform.OS !== "web") {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    Alert.alert(
      "Log Out",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Log Out",
          style: "destructive",
          onPress: async () => {
            await logout();
          },
        },
      ]
    );
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "deal":
        return "check-circle";
      case "cert":
        return "award";
      case "course":
        return "book-open";
      default:
        return "activity";
    }
  };

  const displayName = user?.name || "User";
  const userRole = user?.userType === "company" 
    ? `${user.company || "Company"} Account`
    : "Sales Representative";
  const userBadges = user?.userType === "company"
    ? [{ label: "Company", color: AppColors.secondary }]
    : [{ label: "Top Closer", color: AppColors.accent }, { label: "Sales Rep", color: AppColors.primary }];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop, paddingBottom },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.profileHeader}>
        <Avatar name={displayName} index={0} size={80} />
        <ThemedText type="h2" style={styles.userName}>
          {displayName}
        </ThemedText>
        <ThemedText style={[styles.userRole, { color: theme.textSecondary }]}>
          {userRole}
        </ThemedText>
        <View style={styles.badges}>
          {userBadges.map((badge, index) => (
            <Badge key={index} label={badge.label} color={badge.color} size="medium" />
          ))}
        </View>
      </View>

      <View style={styles.statsContainer}>
        {STATS.map((stat) => (
          <Card key={stat.label} elevation={1} style={styles.statCard}>
            <Feather
              name={stat.icon as any}
              size={20}
              color={AppColors.primary}
              style={styles.statIcon}
            />
            <ThemedText type="h3" style={styles.statValue}>
              {stat.value}
            </ThemedText>
            <ThemedText
              style={[styles.statLabel, { color: theme.textSecondary }]}
            >
              {stat.label}
            </ThemedText>
          </Card>
        ))}
      </View>

      <View style={styles.menuSection}>
        {MENU_ITEMS.map((item) => (
          <Card
            key={item.key}
            elevation={1}
            onPress={() => handleMenuPress(item.key)}
            style={styles.menuItem}
          >
            <View style={styles.menuItemContent}>
              <View
                style={[
                  styles.menuIcon,
                  { backgroundColor: theme.backgroundSecondary },
                ]}
              >
                <Feather
                  name={item.icon as any}
                  size={20}
                  color={AppColors.primary}
                />
              </View>
              <ThemedText type="h4">{item.label}</ThemedText>
            </View>
            <Feather name="chevron-right" size={20} color={theme.textSecondary} />
          </Card>
        ))}
      </View>

      <View style={styles.activitySection}>
        <ThemedText type="h4" style={styles.sectionTitle}>
          Recent Activity
        </ThemedText>
        {RECENT_ACTIVITY.map((activity, index) => (
          <View key={index} style={styles.activityItem}>
            <View
              style={[
                styles.activityIcon,
                { backgroundColor: theme.backgroundDefault },
              ]}
            >
              <Feather
                name={getActivityIcon(activity.type) as any}
                size={16}
                color={AppColors.primary}
              />
            </View>
            <View style={styles.activityContent}>
              <ThemedText style={styles.activityText}>{activity.text}</ThemedText>
              <ThemedText
                style={[styles.activityTime, { color: theme.textSecondary }]}
              >
                {activity.time}
              </ThemedText>
            </View>
          </View>
        ))}
      </View>

      <Pressable
        style={[styles.settingsButton, { borderColor: theme.border }]}
        onPress={() => Alert.alert("Settings", "Settings screen coming soon!")}
      >
        <Feather name="settings" size={20} color={theme.textSecondary} />
        <ThemedText style={{ color: theme.textSecondary, marginLeft: Spacing.sm }}>
          Settings
        </ThemedText>
      </Pressable>

      <Pressable
        style={[styles.logoutButton, { backgroundColor: AppColors.error + "15" }]}
        onPress={handleLogout}
      >
        <Feather name="log-out" size={20} color={AppColors.error} />
        <ThemedText style={{ color: AppColors.error, marginLeft: Spacing.sm, fontWeight: "500" }}>
          Log Out
        </ThemedText>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.xl,
  },
  profileHeader: {
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  userName: {
    marginTop: Spacing.md,
  },
  userRole: {
    marginTop: Spacing.xs,
  },
  badges: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  statsContainer: {
    flexDirection: "row",
    gap: Spacing.md,
    marginBottom: Spacing["2xl"],
  },
  statCard: {
    flex: 1,
    alignItems: "center",
    paddingVertical: Spacing.lg,
  },
  statIcon: {
    marginBottom: Spacing.sm,
  },
  statValue: {
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 11,
    textAlign: "center",
  },
  menuSection: {
    gap: Spacing.md,
    marginBottom: Spacing["2xl"],
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  menuItemContent: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  activitySection: {
    marginBottom: Spacing["2xl"],
  },
  sectionTitle: {
    marginBottom: Spacing.lg,
  },
  activityItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.lg,
  },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.md,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
  },
  settingsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.lg,
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.md,
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.xl,
  },
});
