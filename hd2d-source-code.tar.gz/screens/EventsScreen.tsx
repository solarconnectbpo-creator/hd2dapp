import React, { useState } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Pressable,
  Modal,
  Alert,
  ScrollView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";
import { SearchBar } from "@/components/SearchBar";
import { useTheme } from "@/hooks/useTheme";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing, BorderRadius, AppColors } from "@/constants/theme";
import { EVENTS, Event } from "@/data/mockData";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

const EVENT_TYPE_COLORS: Record<string, string> = {
  conference: AppColors.primary,
  training: AppColors.accent,
  networking: "#8B5CF6",
  "trade-show": "#F59E0B",
};

export default function EventsScreen() {
  const { theme, isDark } = useTheme();
  const { paddingTop, paddingBottom } = useScreenInsets();
  const [searchQuery, setSearchQuery] = useState("");
  const [events, setEvents] = useState(EVENTS);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRsvp = async (event: Event) => {
    if (Platform.OS !== "web") {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setEvents((prev) =>
      prev.map((e) =>
        e.id === event.id
          ? {
              ...e,
              isRsvped: !e.isRsvped,
              attendees: e.isRsvped ? e.attendees - 1 : e.attendees + 1,
            }
          : e
      )
    );
    if (selectedEvent?.id === event.id) {
      setSelectedEvent({
        ...selectedEvent,
        isRsvped: !selectedEvent.isRsvped,
        attendees: selectedEvent.isRsvped
          ? selectedEvent.attendees - 1
          : selectedEvent.attendees + 1,
      });
    }
  };

  const renderEvent = ({ item }: { item: Event }) => (
    <Card
      elevation={1}
      onPress={() => setSelectedEvent(item)}
      style={styles.eventCard}
    >
      <View style={styles.eventHeader}>
        <View
          style={[
            styles.dateBadge,
            { backgroundColor: theme.backgroundSecondary },
          ]}
        >
          <ThemedText style={styles.dateMonth}>
            {item.date.split(" ")[0]}
          </ThemedText>
          <ThemedText type="h3" style={styles.dateDay}>
            {item.date.split(" ")[1].replace(",", "")}
          </ThemedText>
        </View>
        <View style={styles.eventInfo}>
          <ThemedText type="h4" numberOfLines={1}>
            {item.title}
          </ThemedText>
          <View style={styles.eventLocation}>
            <Feather name="map-pin" size={12} color={theme.textSecondary} />
            <ThemedText
              style={[styles.locationText, { color: theme.textSecondary }]}
            >
              {item.location}
            </ThemedText>
          </View>
        </View>
      </View>
      <View style={styles.eventMeta}>
        <Badge
          label={item.type.replace("-", " ")}
          color={EVENT_TYPE_COLORS[item.type]}
        />
        <View style={styles.attendeesContainer}>
          <Feather name="users" size={14} color={theme.textSecondary} />
          <ThemedText
            style={[styles.attendeesText, { color: theme.textSecondary }]}
          >
            {item.attendees} attending
          </ThemedText>
        </View>
      </View>
      <View style={styles.eventFooter}>
        <View style={styles.timeContainer}>
          <Feather name="clock" size={14} color={theme.textSecondary} />
          <ThemedText style={{ color: theme.textSecondary, marginLeft: 4 }}>
            {item.time}
          </ThemedText>
        </View>
        <Pressable
          onPress={() => handleRsvp(item)}
          style={[
            styles.rsvpButton,
            {
              backgroundColor: item.isRsvped
                ? AppColors.accent
                : theme.backgroundSecondary,
            },
          ]}
        >
          <Feather
            name={item.isRsvped ? "check" : "plus"}
            size={16}
            color={item.isRsvped ? "#FFFFFF" : theme.text}
          />
          <ThemedText
            style={[
              styles.rsvpText,
              { color: item.isRsvped ? "#FFFFFF" : theme.text },
            ]}
          >
            {item.isRsvped ? "Going" : "RSVP"}
          </ThemedText>
        </Pressable>
      </View>
    </Card>
  );

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop }]}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search events..."
        />
      </View>
      <FlatList
        data={filteredEvents}
        renderItem={renderEvent}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[styles.listContent, { paddingBottom }]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      <Modal
        visible={!!selectedEvent}
        animationType="slide"
        transparent
        onRequestClose={() => setSelectedEvent(null)}
      >
        <View style={styles.modalOverlay}>
          <ThemedView style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText type="h3">Event Details</ThemedText>
              <Pressable onPress={() => setSelectedEvent(null)}>
                <Feather name="x" size={24} color={theme.text} />
              </Pressable>
            </View>
            {selectedEvent ? (
              <ScrollView style={styles.modalBody}>
                <View style={styles.modalEventHeader}>
                  <Badge
                    label={selectedEvent.type.replace("-", " ")}
                    color={EVENT_TYPE_COLORS[selectedEvent.type]}
                    size="medium"
                  />
                  <ThemedText type="h2" style={styles.modalTitle}>
                    {selectedEvent.title}
                  </ThemedText>
                </View>

                <View style={styles.detailsSection}>
                  <View style={styles.detailRow}>
                    <View
                      style={[
                        styles.detailIcon,
                        { backgroundColor: theme.backgroundDefault },
                      ]}
                    >
                      <Feather name="calendar" size={18} color={AppColors.primary} />
                    </View>
                    <View>
                      <ThemedText type="h4">{selectedEvent.date}</ThemedText>
                      <ThemedText style={{ color: theme.textSecondary }}>
                        {selectedEvent.time}
                      </ThemedText>
                    </View>
                  </View>
                  <View style={styles.detailRow}>
                    <View
                      style={[
                        styles.detailIcon,
                        { backgroundColor: theme.backgroundDefault },
                      ]}
                    >
                      <Feather name="map-pin" size={18} color={AppColors.primary} />
                    </View>
                    <ThemedText type="h4">{selectedEvent.location}</ThemedText>
                  </View>
                  <View style={styles.detailRow}>
                    <View
                      style={[
                        styles.detailIcon,
                        { backgroundColor: theme.backgroundDefault },
                      ]}
                    >
                      <Feather name="users" size={18} color={AppColors.primary} />
                    </View>
                    <ThemedText type="h4">
                      {selectedEvent.attendees} Attending
                    </ThemedText>
                  </View>
                </View>

                <View style={styles.descriptionSection}>
                  <ThemedText type="h4" style={styles.sectionTitle}>
                    About This Event
                  </ThemedText>
                  <ThemedText style={{ color: theme.textSecondary }}>
                    {selectedEvent.description}
                  </ThemedText>
                </View>

                <Button
                  onPress={() => handleRsvp(selectedEvent)}
                  style={[
                    styles.modalRsvpButton,
                    selectedEvent.isRsvped && {
                      backgroundColor: theme.backgroundSecondary,
                    },
                  ]}
                >
                  {selectedEvent.isRsvped ? "Cancel RSVP" : "RSVP to Event"}
                </Button>
              </ScrollView>
            ) : null}
          </ThemedView>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  listContent: {
    paddingHorizontal: Spacing.xl,
  },
  separator: {
    height: Spacing.md,
  },
  eventCard: {
    gap: Spacing.md,
  },
  eventHeader: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  dateBadge: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  dateMonth: {
    fontSize: 11,
    fontWeight: "600",
    textTransform: "uppercase",
    opacity: 0.7,
  },
  dateDay: {
    marginTop: -2,
  },
  eventInfo: {
    flex: 1,
    justifyContent: "center",
  },
  eventLocation: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 4,
  },
  locationText: {
    fontSize: 12,
  },
  eventMeta: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  attendeesContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  attendeesText: {
    fontSize: 12,
  },
  eventFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  timeContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  rsvpButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  rsvpText: {
    fontSize: 13,
    fontWeight: "500",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    borderTopLeftRadius: BorderRadius.xl,
    borderTopRightRadius: BorderRadius.xl,
    maxHeight: "90%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(128,128,128,0.2)",
  },
  modalBody: {
    padding: Spacing.xl,
  },
  modalEventHeader: {
    marginBottom: Spacing.xl,
  },
  modalTitle: {
    marginTop: Spacing.md,
  },
  detailsSection: {
    gap: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  detailIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  descriptionSection: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.sm,
  },
  modalRsvpButton: {
    marginBottom: Spacing["3xl"],
  },
});
