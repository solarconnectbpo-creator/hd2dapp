import React, { useState } from "react";
import { View, StyleSheet, FlatList, Pressable, Modal, Alert } from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { SearchBar } from "@/components/SearchBar";
import { FilterChips } from "@/components/FilterChips";
import { FloatingActionButton } from "@/components/FloatingActionButton";
import { Button } from "@/components/Button";
import { PaymentModal } from "@/components/PaymentModal";
import { useTheme } from "@/hooks/useTheme";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing, BorderRadius, AppColors } from "@/constants/theme";
import { LEADS, INDUSTRIES, LEAD_TYPE_LABELS, Lead } from "@/data/mockData";

const INDUSTRY_COLORS: Record<string, string> = {
  roofing: "#EF4444",
  solar: "#F59E0B",
  windows: "#3B82F6",
  hvac: "#8B5CF6",
  siding: "#10B981",
};

export default function LeadsScreen() {
  const { theme } = useTheme();
  const { paddingTop, paddingBottom } = useScreenInsets();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [leads, setLeads] = useState(LEADS);
  const [showPayment, setShowPayment] = useState(false);

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.contactName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesIndustry = !selectedIndustry || lead.industry === selectedIndustry;
    return matchesSearch && matchesIndustry;
  });

  const handleBuyLead = (lead: Lead) => {
    setShowPayment(true);
  };

  const handlePaymentSuccess = (transactionId: string) => {
    if (selectedLead) {
      setLeads((prev) => prev.filter((l) => l.id !== selectedLead.id));
      setSelectedLead(null);
    }
    setShowPayment(false);
  };

  const renderLead = ({ item }: { item: Lead }) => (
    <Card
      elevation={1}
      onPress={() => setSelectedLead(item)}
      style={styles.leadCard}
    >
      <View style={styles.leadHeader}>
        <Badge
          label={item.industry}
          color={INDUSTRY_COLORS[item.industry]}
          size="medium"
        />
        <View style={styles.qualityBadge}>
          <Feather name="star" size={12} color={AppColors.warning} />
          <ThemedText style={styles.qualityText}>{item.qualityScore}</ThemedText>
        </View>
      </View>
      <ThemedText type="h4" style={styles.leadName}>
        {item.contactName}
      </ThemedText>
      <View style={styles.leadLocation}>
        <Feather name="map-pin" size={14} color={theme.textSecondary} />
        <ThemedText style={[styles.locationText, { color: theme.textSecondary }]}>
          {item.location}
        </ThemedText>
      </View>
      <View style={styles.leadFooter}>
        <ThemedText style={[styles.leadNotes, { color: theme.textSecondary }]} numberOfLines={1}>
          {item.notes}
        </ThemedText>
        <View style={styles.priceContainer}>
          <View style={styles.typeAndPrice}>
            <Badge label={item.leadType.replace("-", " ")} color="#6B7280" size="small" />
            <ThemedText type="h4" style={{ color: AppColors.primary }}>
              ${item.price}
            </ThemedText>
          </View>
        </View>
      </View>
    </Card>
  );

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop }]}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search leads..."
          showFilter
        />
      </View>
      <View style={styles.filtersContainer}>
        <FilterChips
          options={INDUSTRIES.map((i) => ({ key: i.key, label: i.label }))}
          selectedKey={selectedIndustry}
          onSelect={setSelectedIndustry}
        />
      </View>
      <FlatList
        data={filteredLeads}
        renderItem={renderLead}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom },
        ]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      <Modal
        visible={!!selectedLead}
        animationType="slide"
        transparent
        onRequestClose={() => setSelectedLead(null)}
      >
        <View style={styles.modalOverlay}>
          <ThemedView style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText type="h3">Lead Details</ThemedText>
              <Pressable onPress={() => setSelectedLead(null)}>
                <Feather name="x" size={24} color={theme.text} />
              </Pressable>
            </View>
            {selectedLead ? (
              <View style={styles.modalBody}>
                <Badge
                  label={selectedLead.industry}
                  color={INDUSTRY_COLORS[selectedLead.industry]}
                  size="medium"
                  style={styles.modalBadge}
                />
                <ThemedText type="h2" style={styles.modalName}>
                  {selectedLead.contactName}
                </ThemedText>
                <View style={styles.modalRow}>
                  <Feather name="map-pin" size={16} color={theme.textSecondary} />
                  <ThemedText style={{ color: theme.textSecondary, marginLeft: Spacing.sm }}>
                    {selectedLead.location}
                  </ThemedText>
                </View>
                <View style={styles.modalRow}>
                  <Feather name="phone" size={16} color={theme.textSecondary} />
                  <ThemedText style={{ color: theme.textSecondary, marginLeft: Spacing.sm }}>
                    {selectedLead.phone}
                  </ThemedText>
                </View>
                <View style={styles.modalRow}>
                  <Feather name="mail" size={16} color={theme.textSecondary} />
                  <ThemedText style={{ color: theme.textSecondary, marginLeft: Spacing.sm }}>
                    {selectedLead.email}
                  </ThemedText>
                </View>
                <View style={styles.modalSection}>
                  <ThemedText type="h4">Notes</ThemedText>
                  <ThemedText style={{ color: theme.textSecondary, marginTop: Spacing.sm }}>
                    {selectedLead.notes}
                  </ThemedText>
                </View>
                <View style={styles.modalSection}>
                  <View style={styles.qualityRow}>
                    <ThemedText type="h4">Quality Score</ThemedText>
                    <View style={[styles.qualityBadge, { backgroundColor: theme.backgroundSecondary }]}>
                      <Feather name="star" size={14} color={AppColors.warning} />
                      <ThemedText style={styles.qualityText}>{selectedLead.qualityScore}/100</ThemedText>
                    </View>
                  </View>
                </View>
                <View style={styles.priceSection}>
                  <ThemedText style={{ color: theme.textSecondary }}>Lead Type</ThemedText>
                  <ThemedText type="h4" style={{ marginBottom: Spacing.md }}>
                    {LEAD_TYPE_LABELS[selectedLead.leadType]}
                  </ThemedText>
                  <ThemedText style={{ color: theme.textSecondary }}>Your Price</ThemedText>
                  <ThemedText type="h1" style={{ color: AppColors.primary }}>
                    ${selectedLead.price}
                  </ThemedText>
                </View>
                <Button onPress={() => handleBuyLead(selectedLead)}>
                  Purchase Lead
                </Button>
              </View>
            ) : null}
          </ThemedView>
        </View>
      </Modal>

      <PaymentModal
        visible={showPayment && selectedLead !== null}
        onClose={() => setShowPayment(false)}
        amount={selectedLead ? selectedLead.price * 100 : 0}
        currency="USD"
        description={`Quality Score: ${selectedLead?.qualityScore}/100`}
        itemName={`${selectedLead?.industry} Lead - ${selectedLead?.contactName}`}
        onSuccess={handlePaymentSuccess}
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  filtersContainer: {
    marginBottom: Spacing.md,
  },
  listContent: {
    paddingHorizontal: Spacing.xl,
  },
  separator: {
    height: Spacing.md,
  },
  leadCard: {
    gap: Spacing.sm,
  },
  leadHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  qualityBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.xs,
  },
  qualityText: {
    fontSize: 13,
    fontWeight: "600",
  },
  leadName: {
    marginTop: Spacing.xs,
  },
  leadLocation: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  locationText: {
    fontSize: 13,
  },
  leadFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Spacing.xs,
  },
  leadNotes: {
    fontSize: 13,
    flex: 1,
    marginRight: Spacing.md,
  },
  priceContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  typeAndPrice: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    borderTopLeftRadius: BorderRadius.xl,
    borderTopRightRadius: BorderRadius.xl,
    maxHeight: "90%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(128,128,128,0.2)",
  },
  modalBody: {
    padding: Spacing.xl,
  },
  modalBadge: {
    marginBottom: Spacing.sm,
  },
  modalName: {
    marginBottom: Spacing.lg,
  },
  modalRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  modalSection: {
    marginTop: Spacing.xl,
  },
  qualityRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  priceSection: {
    alignItems: "center",
    marginVertical: Spacing["2xl"],
  },
  mapButton: {
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
  },
});
