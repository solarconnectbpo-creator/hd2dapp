import React, { useState } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Pressable,
  Modal,
  TextInput,
  Alert,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Avatar } from "@/components/Avatar";
import { FloatingActionButton } from "@/components/FloatingActionButton";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing, BorderRadius, AppColors, Typography } from "@/constants/theme";
import { POSTS, Post } from "@/data/mockData";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

const MAX_CHARS = 280;

export default function SocialScreen() {
  const { theme, isDark } = useTheme();
  const { paddingTop, paddingBottom } = useScreenInsets();
  const [posts, setPosts] = useState(POSTS);
  const [showComposeModal, setShowComposeModal] = useState(false);
  const [newPostContent, setNewPostContent] = useState("");

  const handleLike = async (postId: string) => {
    if (Platform.OS !== "web") {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? {
              ...post,
              isLiked: !post.isLiked,
              likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            }
          : post
      )
    );
  };

  const handlePost = () => {
    if (!newPostContent.trim()) {
      Alert.alert("Error", "Please enter some content");
      return;
    }

    const hashtags = newPostContent.match(/#\w+/g)?.map((tag) => tag.slice(1)) || [];
    
    const newPost: Post = {
      id: Date.now().toString(),
      userId: "currentUser",
      userName: "You",
      userAvatar: 0,
      content: newPostContent,
      hashtags,
      likes: 0,
      comments: 0,
      isLiked: false,
      createdAt: "Just now",
    };

    setPosts((prev) => [newPost, ...prev]);
    setShowComposeModal(false);
    setNewPostContent("");
  };

  const renderPost = ({ item }: { item: Post }) => (
    <Card elevation={1} style={styles.postCard}>
      <View style={styles.postHeader}>
        <Avatar name={item.userName} index={item.userAvatar} size={44} />
        <View style={styles.postAuthor}>
          <ThemedText type="h4">{item.userName}</ThemedText>
          <ThemedText style={[styles.timestamp, { color: theme.textSecondary }]}>
            {item.createdAt}
          </ThemedText>
        </View>
      </View>
      <ThemedText style={styles.postContent}>{item.content}</ThemedText>
      {item.hashtags.length > 0 ? (
        <View style={styles.hashtags}>
          {item.hashtags.map((tag) => (
            <ThemedText key={tag} style={{ color: AppColors.primary }}>
              #{tag}{" "}
            </ThemedText>
          ))}
        </View>
      ) : null}
      <View style={styles.postActions}>
        <Pressable
          onPress={() => handleLike(item.id)}
          style={styles.actionButton}
        >
          <Feather
            name={item.isLiked ? "heart" : "heart"}
            size={20}
            color={item.isLiked ? AppColors.error : theme.textSecondary}
            style={item.isLiked ? { opacity: 1 } : { opacity: 0.7 }}
          />
          <ThemedText
            style={[
              styles.actionText,
              { color: item.isLiked ? AppColors.error : theme.textSecondary },
            ]}
          >
            {item.likes}
          </ThemedText>
        </Pressable>
        <Pressable style={styles.actionButton}>
          <Feather name="message-circle" size={20} color={theme.textSecondary} style={{ opacity: 0.7 }} />
          <ThemedText style={[styles.actionText, { color: theme.textSecondary }]}>
            {item.comments}
          </ThemedText>
        </Pressable>
        <Pressable style={styles.actionButton}>
          <Feather name="share" size={20} color={theme.textSecondary} style={{ opacity: 0.7 }} />
        </Pressable>
      </View>
    </Card>
  );

  const charsRemaining = MAX_CHARS - newPostContent.length;
  const isOverLimit = charsRemaining < 0;

  return (
    <ThemedView style={styles.container}>
      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingTop, paddingBottom },
        ]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      <FloatingActionButton icon="edit-2" onPress={() => setShowComposeModal(true)} />

      <Modal
        visible={showComposeModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowComposeModal(false)}
      >
        <View style={styles.modalOverlay}>
          <ThemedView style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Pressable onPress={() => setShowComposeModal(false)}>
                <ThemedText style={{ color: theme.textSecondary }}>Cancel</ThemedText>
              </Pressable>
              <ThemedText type="h4">New Post</ThemedText>
              <Pressable onPress={handlePost} disabled={isOverLimit || !newPostContent.trim()}>
                <ThemedText
                  style={{
                    color: isOverLimit || !newPostContent.trim() ? theme.textSecondary : AppColors.primary,
                    fontWeight: "600",
                  }}
                >
                  Post
                </ThemedText>
              </Pressable>
            </View>
            <View style={styles.composeContent}>
              <Avatar name="You" index={0} size={44} />
              <View style={styles.inputContainer}>
                <TextInput
                  style={[styles.composeInput, { color: theme.text }]}
                  value={newPostContent}
                  onChangeText={setNewPostContent}
                  placeholder="What's happening in the field?"
                  placeholderTextColor={theme.textSecondary}
                  multiline
                  maxLength={MAX_CHARS + 20}
                  autoFocus
                />
              </View>
            </View>
            <View style={styles.composeFooter}>
              <ThemedText
                style={[
                  styles.charCount,
                  { color: isOverLimit ? AppColors.error : theme.textSecondary },
                ]}
              >
                {charsRemaining}
              </ThemedText>
            </View>
            <View style={styles.suggestionsContainer}>
              <ThemedText style={[styles.suggestionsTitle, { color: theme.textSecondary }]}>
                Popular hashtags:
              </ThemedText>
              <View style={styles.hashtags}>
                {["doortodoor", "sales", "closing", "roofing", "solar"].map((tag) => (
                  <Pressable
                    key={tag}
                    onPress={() => setNewPostContent((prev) => prev + ` #${tag}`)}
                  >
                    <ThemedText style={{ color: AppColors.primary }}>#{tag} </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>
          </ThemedView>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: Spacing.xl,
  },
  separator: {
    height: Spacing.md,
  },
  postCard: {
    gap: Spacing.md,
  },
  postHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  postAuthor: {
    flex: 1,
  },
  timestamp: {
    fontSize: 12,
    marginTop: 2,
  },
  postContent: {
    fontSize: 15,
    lineHeight: 22,
  },
  hashtags: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  postActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing["2xl"],
    marginTop: Spacing.xs,
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingVertical: Spacing.xs,
  },
  actionText: {
    fontSize: 13,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-start",
  },
  modalContent: {
    flex: 1,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(128,128,128,0.2)",
  },
  composeContent: {
    flexDirection: "row",
    padding: Spacing.xl,
    gap: Spacing.md,
  },
  inputContainer: {
    flex: 1,
  },
  composeInput: {
    fontSize: 17,
    minHeight: 120,
    textAlignVertical: "top",
  },
  composeFooter: {
    alignItems: "flex-end",
    paddingHorizontal: Spacing.xl,
  },
  charCount: {
    fontSize: 13,
  },
  suggestionsContainer: {
    padding: Spacing.xl,
  },
  suggestionsTitle: {
    fontSize: 13,
    marginBottom: Spacing.sm,
  },
});
