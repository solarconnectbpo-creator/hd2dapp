import React, { useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  Modal,
  Alert,
  TextInput,
  Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { Badge } from "@/components/Badge";
import { useTheme } from "@/hooks/useTheme";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing, BorderRadius, AppColors, Typography } from "@/constants/theme";
import { useInboundAgents } from "@/contexts/InboundAgentsContext";
import { useWebhookProcessor } from "@/hooks/useWebhookProcessor";

export default function InboundAgentsScreen() {
  const { theme } = useTheme();
  const { paddingTop, paddingBottom } = useScreenInsets();
  const { agents, incomingCalls, webhookUrl, addAgent, removeAgent, updateAgentStatus, updateWebhookUrl } = useInboundAgents();
  const { sendWebhook, isProcessing: isTestingWebhook } = useWebhookProcessor(webhookUrl);
  const [showAddAgentModal, setShowAddAgentModal] = useState(false);
  const [showWebhookModal, setShowWebhookModal] = useState(false);
  const [agentName, setAgentName] = useState("");
  const [newWebhookUrl, setNewWebhookUrl] = useState(webhookUrl);
  const [webhookStatus, setWebhookStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [webhookMessage, setWebhookMessage] = useState("");

  const handleAddAgent = () => {
    if (!agentName.trim()) {
      Alert.alert("Error", "Please enter agent name");
      return;
    }
    addAgent(agentName);
    setShowAddAgentModal(false);
    setAgentName("");
  };

  const handleUpdateWebhook = () => {
    if (!newWebhookUrl.trim()) {
      Alert.alert("Error", "Please enter webhook URL");
      return;
    }
    updateWebhookUrl(newWebhookUrl);
    setShowWebhookModal(false);
  };

  const toggleAgentStatus = (agentId: string, currentStatus: string) => {
    const newStatus = currentStatus === "online" ? "offline" : "online";
    updateAgentStatus(agentId, newStatus as any);
  };

  const ongoingCalls = incomingCalls.filter((c) => c.status !== "ended");

  const testWebhook = async () => {
    setWebhookStatus("testing");
    const success = await sendWebhook({
      agentId: agents[0]?.id || "test-agent",
      fromNumber: "+1 (555) 123-4567",
      toNumber: "+1 (555) 987-6543",
      timestamp: new Date().toISOString(),
      callId: `test-${Date.now()}`,
      type: "incoming",
      transcript: "Test webhook from HD2D app",
    });

    if (success) {
      setWebhookStatus("success");
      setWebhookMessage("✓ Webhook delivered successfully");
      setTimeout(() => setWebhookStatus("idle"), 3000);
    } else {
      setWebhookStatus("error");
      setWebhookMessage("✗ Webhook delivery failed");
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop, paddingBottom }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <ThemedText type="h2">AI Inbound Agents</ThemedText>
          <ThemedText style={{ color: theme.textSecondary, marginTop: Spacing.sm }}>
            Configure webhook integrations for AI agents
          </ThemedText>
        </View>

        {/* Webhook Configuration */}
        <View style={{ marginTop: Spacing.lg }}>
          <ThemedText type="h3" style={{ marginBottom: Spacing.md }}>
            Webhook Configuration
          </ThemedText>
          <Card
            style={[styles.webhookCard, { backgroundColor: theme.backgroundSecondary }]}
            onPress={() => setShowWebhookModal(true)}
          >
            <View style={styles.webhookContent}>
              <View style={{ flex: 1 }}>
                <ThemedText type="h4">Webhook URL</ThemedText>
                <ThemedText
                  style={{
                    color: theme.textSecondary,
                    marginTop: Spacing.sm,
                    fontSize: 12,
                  }}
                  numberOfLines={2}
                >
                  {webhookUrl}
                </ThemedText>
              </View>
              <Feather name="edit-2" size={20} color={AppColors.primary} />
            </View>
          </Card>

          {/* Test Webhook Button */}
          <Pressable
            style={[
              styles.testButton,
              {
                backgroundColor:
                  webhookStatus === "success"
                    ? AppColors.accent
                    : webhookStatus === "error"
                    ? AppColors.error
                    : AppColors.primary,
                opacity: isTestingWebhook ? 0.7 : 1,
              },
            ]}
            onPress={testWebhook}
            disabled={isTestingWebhook || !webhookUrl.startsWith("http")}
          >
            <Feather
              name={
                webhookStatus === "success"
                  ? "check-circle"
                  : webhookStatus === "error"
                  ? "alert-circle"
                  : "send"
              }
              size={16}
              color="#FFFFFF"
            />
            <ThemedText style={{ marginLeft: Spacing.sm, color: "#FFFFFF", fontWeight: "600" }}>
              {isTestingWebhook ? "Testing..." : webhookStatus === "success" ? "Success!" : "Test Webhook"}
            </ThemedText>
          </Pressable>

          {webhookMessage ? (
            <ThemedText
              style={{
                marginTop: Spacing.sm,
                fontSize: 12,
                color: webhookStatus === "success" ? AppColors.accent : AppColors.error,
              }}
            >
              {webhookMessage}
            </ThemedText>
          ) : null}
        </View>

        {/* Active Calls */}
        {ongoingCalls.length > 0 && (
          <View style={{ marginTop: Spacing.lg }}>
            <ThemedText type="h3" style={{ marginBottom: Spacing.md }}>
              Active Calls ({ongoingCalls.length})
            </ThemedText>
            {ongoingCalls.map((call) => (
              <Card key={call.id} style={[styles.callCard, { backgroundColor: theme.backgroundSecondary }]}>
                <View style={styles.callHeader}>
                  <View>
                    <ThemedText type="h4">
                      {call.fromNumber} → {call.toNumber}
                    </ThemedText>
                    <ThemedText
                      style={{ color: theme.textSecondary, marginTop: Spacing.xs, fontSize: 12 }}
                    >
                      {new Date(call.timestamp).toLocaleTimeString()}
                    </ThemedText>
                  </View>
                  <Badge
                    label={call.status === "connected" ? "Connected" : "Incoming"}
                    color={call.status === "connected" ? AppColors.accent : AppColors.primary}
                  />
                </View>
              </Card>
            ))}
          </View>
        )}

        {/* Agents List */}
        <View style={{ marginTop: Spacing.lg }}>
          <View style={styles.agentsHeader}>
            <ThemedText type="h3">AI Agents ({agents.length})</ThemedText>
            <Pressable
              style={[styles.addButton, { backgroundColor: AppColors.primary }]}
              onPress={() => setShowAddAgentModal(true)}
            >
              <Feather name="plus" size={18} color="#FFFFFF" />
            </Pressable>
          </View>

          {agents.map((agent, index) => (
            <Card key={agent.id} style={[styles.agentCard, { backgroundColor: theme.backgroundSecondary }]}>
              <View style={styles.agentHeader}>
                <View style={{ flex: 1 }}>
                  <ThemedText type="h4">{agent.name}</ThemedText>
                  <View style={styles.agentMetrics}>
                    <View style={styles.metric}>
                      <Feather
                        name="phone"
                        size={14}
                        color={agent.status === "online" ? AppColors.accent : theme.textSecondary}
                      />
                      <ThemedText style={{ marginLeft: Spacing.xs, fontSize: 12 }}>
                        {agent.handledCalls} calls
                      </ThemedText>
                    </View>
                    <View style={styles.metric}>
                      <View
                        style={[
                          styles.statusDot,
                          {
                            backgroundColor:
                              agent.status === "online"
                                ? AppColors.accent
                                : agent.status === "handling_call"
                                ? AppColors.primary
                                : theme.textSecondary,
                          },
                        ]}
                      />
                      <ThemedText style={{ marginLeft: Spacing.xs, fontSize: 12, textTransform: "capitalize" }}>
                        {agent.status.replace("_", " ")}
                      </ThemedText>
                    </View>
                  </View>
                </View>
                <Pressable onPress={() => toggleAgentStatus(agent.id, agent.status)}>
                  <Feather
                    name={agent.status === "online" ? "toggle-right" : "toggle-left"}
                    size={24}
                    color={agent.status === "online" ? AppColors.accent : theme.textSecondary}
                  />
                </Pressable>
              </View>

              {agents.length > 1 && (
                <Pressable
                  style={[styles.removeButton, { borderColor: AppColors.error }]}
                  onPress={() => removeAgent(agent.id)}
                >
                  <Feather name="trash-2" size={14} color={AppColors.error} />
                  <ThemedText style={{ marginLeft: Spacing.xs, color: AppColors.error, fontSize: 12 }}>
                    Remove
                  </ThemedText>
                </Pressable>
              )}
            </Card>
          ))}
        </View>

        {/* How It Works */}
        <View style={{ marginTop: Spacing.xl }}>
          <ThemedText type="h3" style={{ marginBottom: Spacing.md }}>
            How Webhooks Work
          </ThemedText>
          <Card style={[styles.infoCard, { backgroundColor: theme.backgroundSecondary }]}>
            <View style={styles.infoItem}>
              <ThemedText style={{ fontWeight: "600", marginBottom: Spacing.sm }}>
                1. Configure Webhook URL
              </ThemedText>
              <ThemedText style={{ color: theme.textSecondary, fontSize: 12 }}>
                Set your server endpoint to receive incoming call notifications
              </ThemedText>
            </View>
            <View style={[styles.infoItem, { marginTop: Spacing.md }]}>
              <ThemedText style={{ fontWeight: "600", marginBottom: Spacing.sm }}>
                2. Enable AI Agent
              </ThemedText>
              <ThemedText style={{ color: theme.textSecondary, fontSize: 12 }}>
                Toggle agent online to start receiving inbound calls
              </ThemedText>
            </View>
            <View style={[styles.infoItem, { marginTop: Spacing.md }]}>
              <ThemedText style={{ fontWeight: "600", marginBottom: Spacing.sm }}>
                3. Process Calls
              </ThemedText>
              <ThemedText style={{ color: theme.textSecondary, fontSize: 12 }}>
                Your AI processes inbound calls and sends webhook events to your server
              </ThemedText>
            </View>
          </Card>
        </View>
      </ScrollView>

      {/* Add Agent Modal */}
      <Modal visible={showAddAgentModal} transparent animationType="slide">
        <View style={[styles.modalOverlay, { backgroundColor: "rgba(0, 0, 0, 0.5)" }]}>
          <View style={[styles.modalContent, { backgroundColor: theme.backgroundDefault }]}>
            <View style={styles.modalHeader}>
              <ThemedText type="h3">Add AI Agent</ThemedText>
              <Pressable onPress={() => setShowAddAgentModal(false)}>
                <Feather name="x" size={24} color={theme.text} />
              </Pressable>
            </View>

            <TextInput
              style={[styles.input, { backgroundColor: theme.backgroundSecondary, color: theme.text }]}
              placeholder="Agent name"
              placeholderTextColor={theme.textSecondary}
              value={agentName}
              onChangeText={setAgentName}
            />

            <View style={styles.modalActions}>
              <Button
                variant="secondary"
                onPress={() => setShowAddAgentModal(false)}
              >
                Cancel
              </Button>
              <Button onPress={handleAddAgent}>
                Add
              </Button>
            </View>
          </View>
        </View>
      </Modal>

      {/* Webhook URL Modal */}
      <Modal visible={showWebhookModal} transparent animationType="slide">
        <View style={[styles.modalOverlay, { backgroundColor: "rgba(0, 0, 0, 0.5)" }]}>
          <View style={[styles.modalContent, { backgroundColor: theme.backgroundDefault }]}>
            <View style={styles.modalHeader}>
              <ThemedText type="h3">Update Webhook URL</ThemedText>
              <Pressable onPress={() => setShowWebhookModal(false)}>
                <Feather name="x" size={24} color={theme.text} />
              </Pressable>
            </View>

            <ThemedText style={{ color: theme.textSecondary, marginBottom: Spacing.md, fontSize: 12 }}>
              Enter your server endpoint that will receive inbound call events
            </ThemedText>

            <TextInput
              style={[styles.input, { backgroundColor: theme.backgroundSecondary, color: theme.text }]}
              placeholder="https://your-domain.com/webhooks/inbound"
              placeholderTextColor={theme.textSecondary}
              value={newWebhookUrl}
              onChangeText={setNewWebhookUrl}
              multiline
            />

            <View style={styles.modalActions}>
              <Button
                variant="secondary"
                onPress={() => setShowWebhookModal(false)}
              >
                Cancel
              </Button>
              <Button onPress={handleUpdateWebhook}>
                Update
              </Button>
            </View>
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  header: {
    marginBottom: Spacing.lg,
  },
  webhookCard: {
    padding: Spacing.md,
  },
  webhookContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  callCard: {
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  callHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  agentsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  agentCard: {
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  agentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  agentMetrics: {
    flexDirection: "row",
    marginTop: Spacing.sm,
    gap: Spacing.md,
  },
  metric: {
    flexDirection: "row",
    alignItems: "center",
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: BorderRadius.full,
  },
  removeButton: {
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  infoCard: {
    padding: Spacing.md,
  },
  infoItem: {
    paddingVertical: Spacing.sm,
  },
  testButton: {
    marginTop: Spacing.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    marginBottom: Spacing.md,
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
  },
  modalContent: {
    borderTopLeftRadius: BorderRadius.lg,
    borderTopRightRadius: BorderRadius.lg,
    padding: Spacing.lg,
    maxHeight: "80%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  modalActions: {
    flexDirection: "row",
    gap: Spacing.md,
    marginTop: Spacing.lg,
  },
});
