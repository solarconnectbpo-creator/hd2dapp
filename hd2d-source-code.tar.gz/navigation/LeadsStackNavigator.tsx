import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import LeadsScreen from "@/screens/LeadsScreen";
import { HeaderTitle } from "@/components/HeaderTitle";
import { useTheme } from "@/hooks/useTheme";
import { getCommonScreenOptions } from "@/navigation/screenOptions";

export type LeadsStackParamList = {
  Leads: undefined;
  LeadDetail: { leadId: string };
};

const Stack = createNativeStackNavigator<LeadsStackParamList>();

export default function LeadsStackNavigator() {
  const { theme, isDark } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        ...getCommonScreenOptions({ theme, isDark }),
      }}
    >
      <Stack.Screen
        name="Leads"
        component={LeadsScreen}
        options={{
          headerTitle: () => <HeaderTitle title="Leads" />,
        }}
      />
    </Stack.Navigator>
  );
}
