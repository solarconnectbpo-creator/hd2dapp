import React, { useMemo } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { Platform, StyleSheet, View } from "react-native";
import LeadsStackNavigator from "@/navigation/LeadsStackNavigator";
import CRMStackNavigator from "@/navigation/CRMStackNavigator";
import SocialStackNavigator from "@/navigation/SocialStackNavigator";
import EventsStackNavigator from "@/navigation/EventsStackNavigator";
import ProfileStackNavigator from "@/navigation/ProfileStackNavigator";
import InboundAgentsStackNavigator from "@/navigation/InboundAgentsStackNavigator";
import { useTheme } from "@/hooks/useTheme";
import { AppColors, Spacing } from "@/constants/theme";

export type MainTabParamList = {
  LeadsTab: undefined;
  CRMTab: undefined;
  SocialTab: undefined;
  EventsTab: undefined;
  InboundTab: undefined;
  ProfileTab: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();

export default function MainTabNavigator() {
  const { theme, isDark } = useTheme();

  return (
    <Tab.Navigator
      initialRouteName="SocialTab"
      screenOptions={{
        tabBarActiveTintColor: AppColors.primary,
        tabBarInactiveTintColor: theme.tabIconDefault,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: Platform.select({
            ios: "transparent",
            android: theme.backgroundRoot,
            web: theme.backgroundRoot,
          }),
          borderTopWidth: 0,
          elevation: 0,
          height: 70,
          paddingTop: Spacing.sm,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "500",
          marginTop: 2,
        },
        tabBarBackground: () =>
          Platform.OS === "ios" ? (
            <BlurView
              intensity={100}
              tint={isDark ? "dark" : "light"}
              style={StyleSheet.absoluteFill}
            />
          ) : null,
        headerShown: false,
      }}
    >
      <Tab.Screen
        name="LeadsTab"
        component={LeadsStackNavigator}
        options={{
          title: "Leads",
          tabBarIcon: ({ color, size }) => (
            <Feather name="shopping-bag" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="CRMTab"
        component={CRMStackNavigator}
        options={{
          title: "CRM",
          tabBarIcon: ({ color, size }) => (
            <Feather name="bar-chart-2" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="SocialTab"
        component={SocialStackNavigator}
        options={{
          title: "Social",
          tabBarIcon: ({ color, size, focused }) => (
            <View
              style={[
                styles.centerTab,
                {
                  backgroundColor: focused
                    ? AppColors.primary
                    : theme.backgroundSecondary,
                },
              ]}
            >
              <Feather
                name="users"
                size={22}
                color={focused ? "#FFFFFF" : color}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="EventsTab"
        component={EventsStackNavigator}
        options={{
          title: "Events",
          tabBarIcon: ({ color, size }) => (
            <Feather name="calendar" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="InboundTab"
        component={InboundAgentsStackNavigator}
        options={{
          title: "Inbound",
          tabBarIcon: ({ color, size }) => (
            <Feather name="phone-incoming" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileStackNavigator}
        options={{
          title: "Profile",
          tabBarIcon: ({ color, size }) => (
            <Feather name="user" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  centerTab: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 4,
  },
});
