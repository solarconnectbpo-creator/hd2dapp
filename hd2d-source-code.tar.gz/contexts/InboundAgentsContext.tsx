import React, { createContext, useContext, useState, useCallback } from "react";

export interface InboundAgent {
  id: string;
  name: string;
  status: "online" | "offline" | "handling_call";
  webhookUrl: string;
  lastActive: string;
  handledCalls: number;
}

export interface InboundCall {
  id: string;
  agentId: string;
  fromNumber: string;
  toNumber: string;
  timestamp: string;
  duration: number;
  status: "incoming" | "connected" | "ended";
  transcript?: string;
}

interface InboundAgentsContextType {
  agents: InboundAgent[];
  incomingCalls: InboundCall[];
  webhookUrl: string;
  addAgent: (name: string) => void;
  removeAgent: (agentId: string) => void;
  updateAgentStatus: (agentId: string, status: InboundAgent["status"]) => void;
  updateWebhookUrl: (url: string) => void;
  addIncomingCall: (call: InboundCall) => void;
  removeIncomingCall: (callId: string) => void;
  updateCallDuration: (callId: string, duration: number) => void;
}

const InboundAgentsContext = createContext<InboundAgentsContextType | undefined>(undefined);

export const InboundAgentsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [agents, setAgents] = useState<InboundAgent[]>([
    {
      id: "agent-1",
      name: "AI Assistant 1",
      status: "online",
      webhookUrl: "https://your-domain.com/webhooks/inbound",
      lastActive: new Date().toISOString(),
      handledCalls: 0,
    },
  ]);

  const [incomingCalls, setIncomingCalls] = useState<InboundCall[]>([]);
  const [webhookUrl, setWebhookUrl] = useState("https://your-domain.com/webhooks/inbound");

  const addAgent = useCallback((name: string) => {
    const newAgent: InboundAgent = {
      id: Date.now().toString(),
      name,
      status: "offline",
      webhookUrl,
      lastActive: new Date().toISOString(),
      handledCalls: 0,
    };
    setAgents((prev) => [...prev, newAgent]);
  }, [webhookUrl]);

  const removeAgent = useCallback((agentId: string) => {
    setAgents((prev) => prev.filter((a) => a.id !== agentId));
  }, []);

  const updateAgentStatus = useCallback((agentId: string, status: InboundAgent["status"]) => {
    setAgents((prev) =>
      prev.map((a) =>
        a.id === agentId ? { ...a, status, lastActive: new Date().toISOString() } : a
      )
    );
  }, []);

  const updateWebhookUrl = useCallback((url: string) => {
    setWebhookUrl(url);
    setAgents((prev) => prev.map((a) => ({ ...a, webhookUrl: url })));
  }, []);

  const addIncomingCall = useCallback((call: InboundCall) => {
    setIncomingCalls((prev) => [call, ...prev]);
    if (call.status === "connected") {
      updateAgentStatus(call.agentId, "handling_call");
    }
  }, [updateAgentStatus]);

  const removeIncomingCall = useCallback((callId: string) => {
    setIncomingCalls((prev) => prev.filter((c) => c.id !== callId));
  }, []);

  const updateCallDuration = useCallback((callId: string, duration: number) => {
    setIncomingCalls((prev) =>
      prev.map((c) => (c.id === callId ? { ...c, duration } : c))
    );
  }, []);

  return (
    <InboundAgentsContext.Provider
      value={{
        agents,
        incomingCalls,
        webhookUrl,
        addAgent,
        removeAgent,
        updateAgentStatus,
        updateWebhookUrl,
        addIncomingCall,
        removeIncomingCall,
        updateCallDuration,
      }}
    >
      {children}
    </InboundAgentsContext.Provider>
  );
};

export const useInboundAgents = () => {
  const context = useContext(InboundAgentsContext);
  if (!context) {
    throw new Error("useInboundAgents must be used within InboundAgentsProvider");
  }
  return context;
};
