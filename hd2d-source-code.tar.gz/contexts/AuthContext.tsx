import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

export type UserType = "sales_rep" | "company" | "admin";

export interface User {
  id: string;
  email: string;
  name: string;
  userType: UserType;
  company?: string;
  phone?: string;
  createdAt: string;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string, userType: UserType) => Promise<boolean>;
  signup: (data: SignupData) => Promise<boolean>;
  logout: () => Promise<void>;
}

interface SignupData {
  email: string;
  password: string;
  name: string;
  userType: UserType;
  company?: string;
  phone?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_KEY = "auth_user";
const USERS_STORAGE_KEY = "registered_users";

async function secureSet(key: string, value: string): Promise<void> {
  if (Platform.OS === "web") {
    await AsyncStorage.setItem(key, value);
  } else {
    await SecureStore.setItemAsync(key, value);
  }
}

async function secureGet(key: string): Promise<string | null> {
  if (Platform.OS === "web") {
    return AsyncStorage.getItem(key);
  } else {
    return SecureStore.getItemAsync(key);
  }
}

async function secureDelete(key: string): Promise<void> {
  if (Platform.OS === "web") {
    await AsyncStorage.removeItem(key);
  } else {
    await SecureStore.deleteItemAsync(key);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initializeDemoAdmin();
    loadUser();
  }, []);

  const initializeDemoAdmin = async () => {
    try {
      const users = await getRegisteredUsers();
      const adminKey = "admin@hd2d.com_admin";
      if (!users[adminKey]) {
        users[adminKey] = {
          password: "admin123",
          user: {
            id: "admin_001",
            email: "admin@hd2d.com",
            name: "HD2D Admin",
            userType: "admin",
            isAdmin: true,
            createdAt: new Date().toISOString(),
          },
        };
        await saveRegisteredUsers(users);
      }
    } catch (error) {
      console.error("Error initializing demo admin:", error);
    }
  };

  const loadUser = async () => {
    try {
      const userData = await secureGet(AUTH_STORAGE_KEY);
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRegisteredUsers = async (): Promise<Record<string, { password: string; user: User }>> => {
    try {
      const usersData = await AsyncStorage.getItem(USERS_STORAGE_KEY);
      return usersData ? JSON.parse(usersData) : {};
    } catch {
      return {};
    }
  };

  const saveRegisteredUsers = async (users: Record<string, { password: string; user: User }>) => {
    await AsyncStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  };

  const login = async (email: string, password: string, userType: UserType): Promise<boolean> => {
    try {
      const users = await getRegisteredUsers();
      const userKey = `${email.toLowerCase()}_${userType}`;
      const userData = users[userKey];

      if (!userData) {
        return false;
      }

      if (userData.password !== password) {
        return false;
      }

      await secureSet(AUTH_STORAGE_KEY, JSON.stringify(userData.user));
      setUser(userData.user);
      return true;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  };

  const signup = async (data: SignupData): Promise<boolean> => {
    try {
      const users = await getRegisteredUsers();
      const userKey = `${data.email.toLowerCase()}_${data.userType}`;

      if (users[userKey]) {
        return false;
      }

      const newUser: User = {
        id: Date.now().toString(),
        email: data.email.toLowerCase(),
        name: data.name,
        userType: data.userType,
        company: data.company,
        phone: data.phone,
        createdAt: new Date().toISOString(),
      };

      users[userKey] = {
        password: data.password,
        user: newUser,
      };

      await saveRegisteredUsers(users);
      await secureSet(AUTH_STORAGE_KEY, JSON.stringify(newUser));
      setUser(newUser);
      return true;
    } catch (error) {
      console.error("Signup error:", error);
      return false;
    }
  };

  const logout = async () => {
    try {
      await secureDelete(AUTH_STORAGE_KEY);
      setUser(null);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
